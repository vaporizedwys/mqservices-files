import base64
import discord
import fade
import httpx
import json
import os
import time
import requests
from discord.commands import Option
from colorama import Fore
from discord.ext import commands, tasks
from builtins import *
import os
import threading
import time
import timer
from datetime import timedelta

def gavetoken(amount):
     with open('tokens.txt', "r+") as f:
        lines = f.read().split("\n")[amount:]
        f.seek(0);f.truncate(0)
        f.write("\n".join(lines))
    
activity = discord.Activity(type=discord.ActivityType.watching, name="STATUS")

bot = commands.Bot(command_prefix='$', activity=activity, status=discord.Status.online, intents=discord.Intents.all())

settings = json.load(open("settings.json", encoding="utf-8"))

if not os.path.isfile("used.json"):
    used = {}
    json.dump(used, open("used.json", "w", encoding="utf-8"), indent=4)

used = json.load(open("used.json"))


def isAdmin(ctx):
    return str(ctx.author.id) in settings["botAdminId"]


@bot.event
async def on_ready():
    activity = discord.Game(name=".test", type=2)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name=settings['botStatus']))
    print(fade.blackwhite("""
 ██████╗░░█████╗░░█████╗░░██████╗████████╗░██████╗  ███████╗░█████╗░██████╗░  ██╗░░░░░██╗███████╗███████╗
 ██╔══██╗██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔════╝  ██╔════╝██╔══██╗██╔══██╗  ██║░░░░░██║██╔════╝██╔════╝
 ██████╦╝██║░░██║██║░░██║╚█████╗░░░░██║░░░╚█████╗░  █████╗░░██║░░██║██████╔╝  ██║░░░░░██║█████╗░░█████╗░░
 ██╔══██╗██║░░██║██║░░██║░╚═══██╗░░░██║░░░░╚═══██╗  ██╔══╝░░██║░░██║██╔══██╗  ██║░░░░░██║██╔══╝░░██╔══╝░░
 ██████╦╝╚█████╔╝╚█████╔╝██████╔╝░░░██║░░░██████╔╝  ██║░░░░░╚█████╔╝██║░░██║  ███████╗██║██║░░░░░███████╗
 ╚═════╝░░╚════╝░░╚════╝░╚═════╝░░░░╚═╝░░░╚═════╝░  ╚═╝░░░░░░╚════╝░╚═╝░░╚═╝  ╚══════╝╚═╝╚═╝░░░░░╚══════╝

                                 .gg/boostsforlife  │ ! ayo#0069
                                 
                                 [+] Discord Bot Status | Online
"""))


def isWhitelisted(ctx):
    return str(ctx.author.id) in settings["botWhitelistedId"]


def makeUsed(token: str):
    data = json.load(open('used.json', 'r'))
    with open('used.json', "w") as f:
        if data.get(token):
            return
        data[token] = {
            "boostedAt": str(time.time()),
            "boostFinishAt": str(time.time() + 30 * 86400)
        }
        json.dump(data, f, indent=4)


def removeToken(token: str):
    with open('tokens.txt', "r") as f:
        Tokens = f.read().split("\n")
        for t in Tokens:
            if len(t) < 5 or t == token:
                Tokens.remove(t)
        open("tokens.txt", "w").write("\n".join(Tokens))

def gavetoken(amount):
     with open('tokens.txt', "r+") as f:
        lines = f.read().split("\n")[amount:]
        f.seek(0);f.truncate(0)
        f.write("\n".join(lines))


def runBoostshit(invite: str, amount: int, expires: bool):
    if amount % 2 != 0:
        amount += 1

    tokens = get_all_tokens("tokens.txt")
    all_data = []
    tokens_checked = 0
    actually_valid = 0
    boosts_done = 0
    for token in tokens:
        s, headers = get_headers(token)
        profile = validate_token(s, headers)
        tokens_checked += 1

        if profile:
            actually_valid += 1
            data_piece = [s, token, headers, profile]
            all_data.append(data_piece)
            print(f"{Fore.GREEN} > {Fore.WHITE}{profile}")
        else:
            pass
    for data in all_data:
        if boosts_done >= amount:
            return
        s, token, headers, profile = get_items(data)
        boost_data = s.get(f"https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers)
        if boost_data.status_code == 200:
            if len(boost_data.json()) != 0:
                join_outcome, server_id = do_join_server(s, token, headers, profile, invite)
                if join_outcome:
                    for boost in boost_data.json():

                        if boosts_done >= amount:
                            removeToken(token)
                            if expires:
                                makeUsed(token)
                            return
                        boost_id = boost["id"]
                        bosted = do_boost(s, token, headers, profile, server_id, boost_id)
                        if bosted:
                            print(f"{Fore.GREEN} > {Fore.WHITE}{profile} {Fore.MAGENTA}BOOSTED {Fore.WHITE}{invite}")
                            boosts_done += 1
                        else:
                            print(f"{Fore.GREEN} > {Fore.WHITE}{profile} {Fore.RED}ERROR BOOSTING {Fore.WHITE}{invite}")
                    removeToken(token)
                    if expires:
                        makeUsed(token)
                else:
                    print(f"{Fore.RED} > {Fore.WHITE}{profile} {Fore.RED}Error joining {invite}")

            else:
                removeToken(token)
                print(f"{Fore.GREEN} > {Fore.WHITE}{profile} {Fore.RED}BROKE ASS DONT GOT NITRO")


@tasks.loop(seconds=5.0)
async def check_used():
    used = json.load(open("used.json"))
    toremove = []
    for token in used:
        print(token)
        if str(time.time()) >= used[token]["boostFinishAt"]:
            toremove.append(token)

    for token in toremove:
        used.pop(token)
        with open("tokens.txt", "a", encoding="utf-8") as file:
            file.write(f"{token}\n")
            file.close()

    json.dump(used, open("used.json", "w"), indent=4)
    
@bot.slash_command(guild_ids=[settings["guildID"]], name="clearstock", description="Clears the whole bot's stock")
async def clearstock(ctx):
    if not str(ctx.author.id) in settings["ownerid"]:
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description="You are not the owner", color=0x3dad5b))
    os.remove('tokens.txt')
    open('tokens.txt', 'w')
    embed = discord.Embed(title="Success", description=f"Successfully cleared stock", color=0x3dad5b)
    await ctx.respond(embed=embed)
    
@bot.slash_command(name="activity", description="Change the Activity of the Boost Bot!")
async def activity(ctx,
                   activity: discord.Option(str,"Change the bot activity",required=True)):
    if not isAdmin(ctx):
        embed = discord.Embed(embed=discord.Embed(title="Access Denied", description=f"You are not an admin", color=0x3dad5b))
        return await ctx.respond(embed=embed)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name=f"{activity}"))
    embed = discord.Embed(title="Success", description=f"Bot activity successfully changed to ``{activity}``", color=0x3dad5b)
    await ctx.respond(embed=embed)
    
@bot.slash_command(guild_ids=[settings["guildID"]], name="restart", description="Restarts your Boost Bot!")
async def restart(ctx):
    if not str(ctx.author.id) in settings["botAdminId"]:
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description=f"You are not an admin", color=0x3dad5b))
    embed=discord.Embed(title="Restarting", description=f"Bot is Restarting...", color=0x3dad5b)
    await ctx.respond(embed=embed)
    print(f"[{Fore.LIGHTBLUE_EX}{time.strftime('%H:%M:%S', time.gmtime())}{Fore.RESET}] Exiting For Restart in 5 Seconds!")
    embed=discord.Embed(title="Success", description=f"Bot succesfully restarted!", color=0x3dad5b)
    await ctx.send(embed=embed)
    os.system("python main.py")
    os.system("cls")
    time.sleep(5)
    exit()

@bot.slash_command(guild_ids=[settings["guildID"]], name="addadmin", description="Adds admin to the bot")
async def whitelist(ctx: discord.ApplicationContext,
                    user: discord.Option(discord.Member, "Member to admin", required=True)):
    if not isAdmin(ctx):
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description=f"You are not an admin", color=0x3dad5b))

    settings["botAdminId"].append(str(user.id))
    json.dump(settings, open("settings.json", "w", encoding="utf-8"), indent=4)

    return await ctx.respond(embed=discord.Embed(title="Success", description=f"Successfully gave admin.", color=0x3dad5b))

@bot.slash_command(guild_ids=[settings["guildID"]], name="stock", description="Allows you to see the current token stock and boost stock!")
async def stock(ctx):
    embed=discord.Embed(title="Stock", description=f"There are {len(open('tokens.txt', encoding='utf-8').read().splitlines()) * 2} boosts in stock", color=0x3dad5b)
    await ctx.respond(embed=embed)

@bot.slash_command(guild_ids=[settings["guildID"]], name="restock", description="Paste.ee link")
async def restock(ctx, paste_ee_link: str):
    if not str(ctx.author.id) in settings["botAdminId"]:
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description="You are not an owner", color=0x3dad5b))
    if not "https://paste.ee/p/" in paste_ee_link:
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description="Please input a valid paste.ee link", color=0x3dad5b))
    link = paste_ee_link
    code = link.replace('https://paste.ee/p/', '')
    r = requests.get(f"https://paste.ee/r/{code}")
    message = await ctx.send(embed=discord.Embed(title="Restocking", description="Restocking, please be patient...", color=0x3dad5b))
    message
    content = r.text
    with open("tokens.txt", "a") as f:
        f.write(content)
    time.sleep(2)
    await ctx.send(embed=discord.Embed(title="Restocked", description="Sucessfully restocked!", color=0x3dad5b))
    await ctx.respond("Succesfully restocked from link: __https://paste.ee/r/{code}__", ephemeral=True)

@bot.slash_command(guild_ids=[settings["guildID"]], name="givetkns", description="Send tokens to user")
async def sendtokens(ctx, amount: int, member: discord.Option(discord.Member, "Member to give tokens", required=True)):
    if not str(ctx.author.id) in settings["ownerid"]:
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description="You are not the owner", color=0x3dad5b))
    mytokens = open("tokens.txt", "r")
    contents = mytokens.readlines()
    amountss = 0
    message = ctx.send(embed=discord.Embed(title="Getting tokens", description="Gettings tokens from tokens.txt", color=0x3dad5b))
    with open("senttokens.txt", "w") as f:
        for i in range(amount):
            f.write(contents[amountss])
            amountss += 1
    gavetoken(amount)
    channel = await member.create_dm()
    await channel.send(file=discord.File('senttokens.txt'))
    os.remove("senttokens.txt")
    await ctx.respond(embed=discord.Embed(title="Tokens Sent", description=f"Tokens succesfully sent to user!", color=0x3dad5b))

@bot.slash_command(guild_ids=[settings["guildID"]], name="boost",
                   description="Allows you to boost a server with Nitro Tokens.")
async def boost(ctx,
                invitecode: Option(str, "Discord Invite Code to join the server (Part after .gg/).", required=True),
                amount: Option(int, "Number of times to boost.", required=True),
                days: Option(int, "Number of days the boosts will stay.", required=True)):
    if not isAdmin(ctx):
        return await ctx.respond(embed=discord.Embed(title="Access Denied", description="You are not an admin", color=0x3dad5b))

    await ctx.respond(embed=discord.Embed(title="Boosting", description="Boosting has been started...", color=0x3dad5b))

    INVITE = invitecode.replace("//", "")
    if "/invite/" in INVITE:
        INVITE = INVITE.split("/invite/")[1]

    elif "/" in INVITE:
        INVITE = INVITE.split("/")[1]

    dataabotinvite = httpx.get(f"https://discord.com/api/v9/invites/{INVITE}").text

    if '{"message": "Unknown Invite", "code": 10006}' in dataabotinvite:
        print(f"{Fore.RED}discord.gg/{INVITE} is invalid")
        return await ctx.edit("The Invite link you provided is invalid!")
    else:
        print(f"{Fore.GREEN}discord.gg/{INVITE} appears to be a valid server")

    EXP = True
    if days == 90:
        EXP = False

    runBoostshit(INVITE, amount, EXP)

    return await ctx.respond(embed=discord.Embed(title="Server Boosted", description="Boosting has been finished!", color=0x3dad5b))


def get_super_properties():
    properties = '''{"os":"Windows","browser":"Chrome","device":"","system_locale":"en-GB","browser_user_agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36","browser_version":"95.0.4638.54","os_version":"10","referrer":"","referring_domain":"","referrer_current":"","referring_domain_current":"","release_channel":"stable","client_build_number":102113,"client_event_source":null}'''
    properties = base64.b64encode(properties.encode()).decode()
    return properties


def get_fingerprint(s):
    try:
        fingerprint = s.get(f"https://discord.com/api/v9/experiments", timeout=5).json()["fingerprint"]
        return fingerprint
    except Exception as e:
        # print(e)
        return "Error"


def get_cookies(s, url):
    try:
        cookieinfo = s.get(url, timeout=5).cookies
        dcf = str(cookieinfo).split('__dcfduid=')[1].split(' ')[0]
        sdc = str(cookieinfo).split('__sdcfduid=')[1].split(' ')[0]
        return dcf, sdc
    except:
        return "", ""


def get_proxy():
    return None  # can change if problems occur


def get_headers(token):
    while True:
        s = httpx.Client(proxies=get_proxy())
        dcf, sdc = get_cookies(s, "https://discord.com/")
        fingerprint = get_fingerprint(s)
        if fingerprint != "Error":  # Making sure I get both headers
            break

    super_properties = get_super_properties()
    headers = {
        'authority': 'discord.com',
        'method': 'POST',
        'path': '/api/v9/users/@me/channels',
        'scheme': 'https',
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'en-US',
        'authorization': token,
        'cookie': f'__dcfduid={dcf}; __sdcfduid={sdc}',
        'origin': 'https://discord.com',
        'sec-ch-ua': '"Google Chrome";v="95", "Chromium";v="95", ";Not A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36',

        'x-debug-options': 'bugReporterEnabled',
        'x-fingerprint': fingerprint,
        'x-super-properties': super_properties,
    }

    return s, headers


def find_token(token):
    if ':' in token:
        token_chosen = None
        tokensplit = token.split(":")
        for thing in tokensplit:
            if '@' not in thing and '.' in thing and len(
                    thing) > 30:  # trying to detect where the token is if a user pastes email:pass:token (and we don't know the order)
                token_chosen = thing
                break
        if token_chosen is None:
            print(f"Error finding token", Fore.RED)
            return None
        else:
            return token_chosen


    else:
        return token


def get_all_tokens(filename):
    all_tokens = []
    with open(filename, 'r') as f:
        for line in f.readlines():
            token = line.strip()
            token = find_token(token)
            if token is not None:
                all_tokens.append(token)

    return all_tokens


def validate_token(s, headers):
    check = s.get(f"https://discord.com/api/v9/users/@me", headers=headers)

    if check.status_code == 200:
        profile_name = check.json()["username"]
        profile_discrim = check.json()["discriminator"]
        profile_of_user = f"{profile_name}#{profile_discrim}"
        return profile_of_user
    else:
        return False


def do_member_gate(s, token, headers, profile, invite, server_id):
    outcome = False
    try:
        member_gate = s.get(
            f"https://discord.com/api/v9/guilds/{server_id}/member-verification?with_guild=false&invite_code={invite}",
            headers=headers)
        if member_gate.status_code != 200:
            return outcome
        accept_rules_data = member_gate.json()
        accept_rules_data["response"] = "true"

        # del headers["content-length"] #= str(len(str(accept_rules_data))) #Had too many problems
        # del headers["content-type"] # = 'application/json'  ^^^^

        accept_member_gate = s.put(f"https://discord.com/api/v9/guilds/{server_id}/requests/@me", headers=headers,
                                   json=accept_rules_data)
        if accept_member_gate.status_code == 201:
            outcome = True

    except:
        pass

    return outcome


def do_join_server(s, token, headers, profile, invite):
    join_outcome = False
    server_id = None
    try:
        # headers["content-length"] = str(len(str(server_join_data)))
        headers["content-type"] = 'application/json'

        for i in range(15):
            try:
                createTask = httpx.post("https://api.capmonster.cloud/createTask", json={
                    "clientKey": settings["capmonsterKey"],
                    "task": {
                        "type": "HCaptchaTaskProxyless",
                        "websiteURL": "https://discord.com/channels/@me",
                        "websiteKey": "76edd89a-a91d-4140-9591-ff311e104059"
                    }
                }).json()["taskId"]

                print(f"Captcha Task: {createTask}")

                getResults = {"status": "processing"}
                while getResults["status"] == "processing":
                    getResults = httpx.post("https://api.capmonster.cloud/getTaskResult", json={
                        "clientKey": settings["capmonsterKey"],
                        "taskId": createTask
                    }).json()
                    time.sleep(1)
                solution = getResults["solution"]["gRecaptchaResponse"]
                print(f"Captcha Solved")
                join_server = s.post(f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={"captcha_key": solution})
                break
            except:
                pass

        server_invite = invite
        if join_server.status_code == 200:
            join_outcome = True
            server_name = join_server.json()["guild"]["name"]
            server_id = join_server.json()["guild"]["id"]
            print(f"{Fore.GREEN} > {Fore.WHITE}{profile} {Fore.GREEN}> {Fore.WHITE}{server_invite}")
    except:
        pass

    return join_outcome, server_id


def do_boost(s, token, headers, profile, server_id, boost_id):
    boost_data = {"user_premium_guild_subscription_slot_ids": [f"{boost_id}"]}
    headers["content-length"] = str(len(str(boost_data)))
    headers["content-type"] = 'application/json'

    boosted = s.put(f"https://discord.com/api/v9/guilds/{server_id}/premium/subscriptions", json=boost_data,
                    headers=headers)
    if boosted.status_code == 201:
        return True
    else:
        return False


def get_invite():
    while True:
        print(f"{Fore.CYAN}Server invite?", end="")
        invite = input(" > ").replace("//", "")

        if "/invite/" in invite:
            invite = invite.split("/invite/")[1]

        elif "/" in invite:
            invite = invite.split("/")[1]

        dataabotinvite = httpx.get(f"https://discord.com/api/v9/invites/{invite}").text

        if '{"message": "Unknown Invite", "code": 10006}' in dataabotinvite:
            print(f"{Fore.RED}discord.gg/{invite} is invalid")
        else:
            print(f"{Fore.GREEN}discord.gg/{invite} appears to be a valid server")
            break

    return invite


def get_items(item):
    s = item[0]
    token = item[1]
    headers = item[2]
    profile = item[3]
    return s, token, headers, profile


bot.run(settings["botToken"])

input()